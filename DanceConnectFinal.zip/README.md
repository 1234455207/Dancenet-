
# DanceConnect Mobile App

DanceConnect is a social learning platform for dancers. Users can register as teachers or students, follow others, post videos, livestream dance lessons, chat, and more.

## 🔧 Features
- Login/Signup (email)
- Teacher/Student account switch
- Upload dance videos (camera/audio access)
- Livestream placeholder (for future integration)
- Chat with followers
- Follow/Unfollow
- Clean mobile design

## 🛠 How to Build APK

1. Clone the repo:
   git clone https://github.com/yourname/danceconnect.git
   cd danceconnect

2. Install dependencies:
   npm install

3. Build the web version:
   npm run build

4. Setup Capacitor:
   npx cap init
   npx cap add android
   npx cap copy

5. Open in Android Studio:
   npx cap open android

6. In Android Studio:
   - Let Gradle sync
   - Click Build > Build APK

7. Find the APK:
   android/app/build/outputs/apk/debug/app-debug.apk
