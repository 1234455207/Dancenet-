import React from 'react';
export default function App() {
  return (
    <div>
      <h1>DanceConnect</h1>
      <p>Welcome to the dance learning platform!</p>
      <ul>
        <li>🧑‍🏫 Teacher/Student switch</li>
        <li>📸 Upload dance videos</li>
        <li>📡 Livestream support (coming soon)</li>
        <li>💬 Chat with followers</li>
        <li>👣 Follow/Unfollow system</li>
      </ul>
    </div>
  );
}
